// vault is the CLI. It never stores the vault key itself: `init` and
// `daemon start` derive/unwrap the key, verify it, hand it to vaultd via a
// pipe and forget it. All other commands talk to vaultd over its socket.
package main

import (
	"bufio"
	"bytes"
	"encoding/hex"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"strconv"
	"strings"
	"syscall"
	"time"

	vcrypto "vault-system/pkg/crypto"
	"vault-system/pkg/ipc"
	"vault-system/pkg/keys"
	"vault-system/pkg/server"
	"vault-system/pkg/spawn"
	"vault-system/pkg/tty"
	"vault-system/pkg/vaultfile"
)

const usage = `Usage:
  vault init --password [--force]        Create ~/.vault (AES-256-GCM, PBKDF2) and start vaultd
  vault init --key PATH [--force]        Create ~/.vault protected by an SSH key (RSA / Ed25519 / ECDSA P-256)
  vault daemon start [--password | --key PATH]
                                         Start vaultd for an existing vault (e.g. after reboot)
  vault add KEY [VALUE]                  Store a credential. Without VALUE: hidden prompt,
                                         or read from stdin if piped (one trailing newline stripped)
  vault get KEY                          Print a credential
  vault list                             List credential names
  vault rm KEY                           Delete a credential
  vault status                           Show whether vaultd is running
  vault stop                             Stop vaultd (SIGTERM)

Secrets (password, passphrase) are only ever read from /dev/tty.
`

func main() {
	if len(os.Args) < 2 {
		fmt.Fprint(os.Stderr, usage)
		os.Exit(2)
	}
	var err error
	args := os.Args[2:]
	switch os.Args[1] {
	case "init":
		err = cmdInit(args)
	case "daemon":
		if len(args) < 1 || args[0] != "start" {
			err = usageErr("usage: vault daemon start [--password | --key PATH]")
		} else {
			err = cmdDaemonStart(args[1:])
		}
	case "add":
		err = cmdAdd(args)
	case "get":
		err = cmdGet(args)
	case "list", "ls":
		err = cmdList(args)
	case "rm", "delete":
		err = cmdRm(args)
	case "status":
		err = cmdStatus()
	case "stop":
		err = cmdStop()
	case "help", "-h", "--help":
		fmt.Print(usage)
	default:
		err = usageErr(fmt.Sprintf("unknown command %q\n\n%s", os.Args[1], usage))
	}
	if err != nil {
		var ue usageError
		fmt.Fprintln(os.Stderr, "error:", err)
		if errors.As(err, &ue) {
			os.Exit(2)
		}
		os.Exit(1)
	}
}

type usageError struct{ msg string }

func (u usageError) Error() string { return u.msg }
func usageErr(msg string) error    { return usageError{msg} }

// ---------------------------------------------------------------- init

func cmdInit(args []string) error {
	fs := flag.NewFlagSet("init", flag.ContinueOnError)
	usePw := fs.Bool("password", false, "protect the vault with a password")
	keyPath := fs.String("key", "", "protect the vault with this SSH private key")
	force := fs.Bool("force", false, "replace an existing vault (old file is kept as ~/.vault.bak.<epoch>)")
	if err := fs.Parse(args); err != nil {
		return usageErr("usage: vault init --password | --key PATH [--force]")
	}
	if *usePw == (*keyPath != "") || fs.NArg() > 0 {
		return usageErr("usage: vault init --password | --key PATH [--force]")
	}

	vaultPath, err := vaultfile.DefaultPath()
	if err != nil {
		return err
	}
	exists := false
	if _, err := os.Lstat(vaultPath); err == nil {
		exists = true
		if !*force {
			return fmt.Errorf("vault already exists at %s (use 'vault daemon start' to unlock it, or 'vault init --force' to replace it)", vaultPath)
		}
	}
	if resp, err := ipc.Call(ipc.Request{Op: "ping"}); err == nil && resp.OK {
		return fmt.Errorf("vaultd is running (PID: %d); run 'vault stop' first", resp.PID)
	}

	h := vaultfile.Header{CreatedAt: time.Now().Unix()}
	var key []byte
	if *usePw {
		fmt.Println("Initialisiere Vault mit SYMMETRISCHER Verschlüsselung (AES-256-GCM, PBKDF2)...")
		pw, err := tty.ReadPassword("Vault password: ")
		if err != nil {
			return err
		}
		defer vcrypto.Zero(pw)
		if len(pw) == 0 {
			return errors.New("empty password")
		}
		pw2, err := tty.ReadPassword("Repeat password: ")
		if err != nil {
			return err
		}
		defer vcrypto.Zero(pw2)
		if !bytes.Equal(pw, pw2) {
			return errors.New("passwords do not match")
		}
		salt, err := vcrypto.Random(16)
		if err != nil {
			return err
		}
		h.KeyType = vaultfile.KeyTypePassword
		h.Salt = hex.EncodeToString(salt)
		h.PBKDF2Iterations = vaultfile.DefaultPBKDF2Iterations
		key = vcrypto.DeriveKey(pw, salt, h.PBKDF2Iterations)
	} else {
		fmt.Println("Initialisiere Vault mit ASYMMETRISCHER Verschlüsselung (RSA-OAEP / ECDH-AES)...")
		priv, err := keys.Load(*keyPath, passphrasePrompt(*keyPath))
		if err != nil {
			return err
		}
		key, err = keys.Wrap(priv, &h)
		if err != nil {
			return err
		}
	}
	defer vcrypto.Zero(key)

	data, err := vaultfile.Create(&h, key, &vaultfile.Payload{Credentials: map[string]string{}})
	if err != nil {
		return err
	}
	if exists {
		bak, err := vaultfile.Backup(vaultPath)
		if err != nil {
			return fmt.Errorf("backing up existing vault: %w", err)
		}
		fmt.Printf("Previous vault moved to %s\n", bak)
	}
	if err := vaultfile.WriteAtomic(vaultPath, data); err != nil {
		return fmt.Errorf("writing vault: %w", err)
	}
	fmt.Printf("Vault created: %s (keytype: %s)\n", vaultPath, h.KeyType)

	pid, err := spawn.Start(key)
	if err != nil {
		return fmt.Errorf("vault created, but vaultd failed to start: %w", err)
	}
	fmt.Printf("vaultd started (PID: %d)\n", pid)
	return nil
}

// ---------------------------------------------------------------- daemon start

func cmdDaemonStart(args []string) error {
	fs := flag.NewFlagSet("daemon start", flag.ContinueOnError)
	usePw := fs.Bool("password", false, "unlock with password")
	keyPath := fs.String("key", "", "unlock with this SSH private key")
	if err := fs.Parse(args); err != nil || fs.NArg() > 0 || (*usePw && *keyPath != "") {
		return usageErr("usage: vault daemon start [--password | --key PATH]")
	}

	vaultPath, err := vaultfile.DefaultPath()
	if err != nil {
		return err
	}
	f, err := vaultfile.Load(vaultPath)
	if err != nil {
		return err
	}
	if resp, err := ipc.Call(ipc.Request{Op: "ping"}); err == nil && resp.OK {
		return fmt.Errorf("vaultd is already running (PID: %d)", resp.PID)
	}

	isPw := f.Header.KeyType == vaultfile.KeyTypePassword
	switch {
	case *usePw && !isPw:
		return fmt.Errorf("this vault is protected by an SSH key (%s); use: vault daemon start --key PATH", f.Header.KeyType)
	case *keyPath != "" && isPw:
		return errors.New("this vault is password protected; use: vault daemon start --password")
	case !*usePw && *keyPath == "" && !isPw:
		return fmt.Errorf("this vault is protected by an SSH key (%s); use: vault daemon start --key PATH", f.Header.KeyType)
	}

	var key []byte
	if isPw {
		salt, err := hex.DecodeString(f.Header.Salt)
		if err != nil {
			return fmt.Errorf("invalid salt in vault header: %w", err)
		}
		pw, err := tty.ReadPassword("Vault password: ")
		if err != nil {
			return err
		}
		key = vcrypto.DeriveKey(pw, salt, f.Header.PBKDF2Iterations)
		vcrypto.Zero(pw)
	} else {
		priv, err := keys.Load(*keyPath, passphrasePrompt(*keyPath))
		if err != nil {
			return err
		}
		if key, err = keys.Unwrap(priv, &f.Header); err != nil {
			return err
		}
	}
	defer vcrypto.Zero(key)

	if _, err := f.Open(key); err != nil {
		return err // "failed to decrypt vault (wrong password or key)"
	}
	pid, err := spawn.Start(key)
	if err != nil {
		return fmt.Errorf("vaultd failed to start: %w", err)
	}
	fmt.Printf("vaultd started (PID: %d)\n", pid)
	return nil
}

func passphrasePrompt(path string) keys.PassphraseFunc {
	return func() ([]byte, error) { return tty.ReadPassword("Passphrase for " + path + ": ") }
}

// ---------------------------------------------------------------- add / get / list / rm

func call(req ipc.Request) (*ipc.Response, error) {
	resp, err := ipc.Call(req)
	if errors.Is(err, ipc.ErrNotRunning) {
		return nil, errors.New("vaultd not running (start it with 'vault daemon start')")
	}
	if err != nil {
		return nil, err
	}
	if !resp.OK {
		return nil, errors.New(resp.Error)
	}
	return resp, nil
}

func cmdAdd(args []string) error {
	if len(args) < 1 || len(args) > 2 || args[0] == "" {
		return usageErr("usage: vault add KEY [VALUE]")
	}
	var value string
	if len(args) == 2 {
		value = args[1]
	} else if tty.IsTerminal(os.Stdin.Fd()) {
		v, err := tty.ReadPassword("Value for " + args[0] + ": ")
		if err != nil {
			return err
		}
		value = string(v)
		vcrypto.Zero(v)
	} else {
		b, err := io.ReadAll(io.LimitReader(bufio.NewReader(os.Stdin), server.MaxValueLen+1))
		if err != nil {
			return fmt.Errorf("reading value from stdin: %w", err)
		}
		if len(b) > server.MaxValueLen {
			return errors.New("value too large")
		}
		b = bytes.TrimSuffix(b, []byte("\n"))
		b = bytes.TrimSuffix(b, []byte("\r"))
		value = string(b)
		vcrypto.Zero(b)
	}
	if _, err := call(ipc.Request{Op: "add", Key: args[0], Value: value}); err != nil {
		return err
	}
	fmt.Fprintf(os.Stderr, "stored: %s\n", args[0])
	return nil
}

func cmdGet(args []string) error {
	if len(args) != 1 {
		return usageErr("usage: vault get KEY")
	}
	resp, err := call(ipc.Request{Op: "get", Key: args[0]})
	if err != nil {
		return err
	}
	// Raw value when piped (e.g. into xclip); newline for humans.
	if tty.IsTerminal(os.Stdout.Fd()) {
		fmt.Println(resp.Value)
	} else {
		fmt.Print(resp.Value)
	}
	return nil
}

func cmdList(args []string) error {
	if len(args) != 0 {
		return usageErr("usage: vault list")
	}
	resp, err := call(ipc.Request{Op: "list"})
	if err != nil {
		return err
	}
	for _, k := range resp.Keys {
		fmt.Println(k)
	}
	return nil
}

func cmdRm(args []string) error {
	if len(args) != 1 {
		return usageErr("usage: vault rm KEY")
	}
	if _, err := call(ipc.Request{Op: "delete", Key: args[0]}); err != nil {
		return err
	}
	fmt.Fprintf(os.Stderr, "deleted: %s\n", args[0])
	return nil
}

// ---------------------------------------------------------------- status / stop

func cmdStatus() error {
	resp, err := ipc.Call(ipc.Request{Op: "ping"})
	if err != nil || !resp.OK {
		fmt.Println("not running")
		os.Exit(3)
	}
	up := time.Since(time.Unix(resp.StartedAt, 0)).Round(time.Second)
	fmt.Printf("running (PID: %d, uptime: %s, keytype: %s)\n", resp.PID, up, resp.KeyType)
	return nil
}

func cmdStop() error {
	pidPath, err := ipc.PIDPath()
	if err != nil {
		return err
	}
	b, err := os.ReadFile(pidPath)
	if err != nil {
		if _, perr := ipc.Call(ipc.Request{Op: "ping"}); perr == nil {
			return errors.New("vaultd is running but its pid file is missing")
		}
		fmt.Println("not running")
		return nil
	}
	pid, err := strconv.Atoi(strings.TrimSpace(string(b)))
	if err != nil || pid <= 1 {
		return fmt.Errorf("invalid pid file %s", pidPath)
	}
	if !isOurVaultd(pid) {
		os.Remove(pidPath)
		fmt.Println("not running (removed stale pid file)")
		return nil
	}
	if err := syscall.Kill(pid, syscall.SIGTERM); err != nil {
		return fmt.Errorf("sending SIGTERM to %d: %w", pid, err)
	}
	for i := 0; i < 100; i++ {
		if syscall.Kill(pid, 0) == syscall.ESRCH || !isOurVaultd(pid) {
			fmt.Printf("vaultd stopped (PID: %d)\n", pid)
			return nil
		}
		time.Sleep(50 * time.Millisecond)
	}
	return fmt.Errorf("vaultd (PID: %d) did not exit within 5s", pid)
}

// isOurVaultd guards against PID reuse: the process must be named vaultd,
// belong to us and not be a zombie.
func isOurVaultd(pid int) bool {
	b, err := os.ReadFile(fmt.Sprintf("/proc/%d/status", pid))
	if err != nil {
		return false
	}
	var name, state string
	uid := -1
	for _, line := range strings.Split(string(b), "\n") {
		k, v, _ := strings.Cut(line, ":")
		v = strings.TrimSpace(v)
		switch k {
		case "Name":
			name = v
		case "State":
			state = v
		case "Uid":
			if f := strings.Fields(v); len(f) > 0 {
				uid, _ = strconv.Atoi(f[0])
			}
		}
	}
	return name == spawn.DaemonName && uid == os.Getuid() && !strings.HasPrefix(state, "Z")
}
