# vault / vaultd

A small credential vault for the shell, built on an agent model like `ssh-agent`.
`vaultd` holds the vault key in memory and answers requests on a Unix socket.
The key never leaves the daemon and is never exported to the environment.

## Usage

```sh
vault init --password                 # symmetric:  AES-256-GCM, key = PBKDF2-SHA256(password, 100k)
vault init --key ~/.ssh/id_ed25519    # asymmetric: RSA-OAEP / ECDH (Ed25519, ECDSA P-256)
vault init ... --force                # replace existing ~/.vault (old one → ~/.vault.bak.<epoch>)

vault add github_token ghp_xxx        # value in argv (visible in ps / shell history!)
vault add github_token                # hidden prompt on the terminal
cat key.pem | vault add deploy_key    # from stdin (one trailing newline is stripped)
vault get github_token                # raw value when piped, with newline on a terminal
vault list
vault rm github_token

vault status                          # running (PID: 1234, uptime: 5m3s, keytype: password) | not running (exit 3)
vault stop                            # SIGTERM to vaultd
vault daemon start --password         # after reboot / stop
vault daemon start --key ~/.ssh/id_ed25519
```

Passwords and key passphrases are **only** read from `/dev/tty`, never from
argv, environment or stdin.

## Architecture

```
vault init / daemon start                      vaultd
  read password/passphrase from /dev/tty         read hex(key) from fd 3, close it
  derive (PBKDF2) or unwrap (RSA/ECDH) key       prctl(PR_SET_NAME "vaultd"), PR_SET_DUMPABLE=0
  verify key decrypts ~/.vault                   verify key decrypts ~/.vault
  spawn vaultd: key → pipe fd 3  ───────────▶    listen $XDG_RUNTIME_DIR/vault.sock (0600)
                  status ◀── pipe fd 4 ───────   write vault.pid (0600), "OK" on fd 4
                                                 per connection: SO_PEERCRED uid check,
vault add/get/list/rm  ── JSON over socket ──▶    decrypt file, answer, re-encrypt on change
vault stop             ── SIGTERM (pid file) ─▶   remove socket + pid file, zero key, exit
```

* vaultd's argv is just `vaultd`. Its environment is only `HOME` and `XDG_RUNTIME_DIR`. It runs in its own session with cwd `/`.
* `PR_SET_DUMPABLE=0` means other processes of the same user can't ptrace it or read `/proc/PID/{mem,environ,cwd}`, and it writes no core dumps.
* The client checks the daemon's UID too (mutual SO_PEERCRED).
* If `XDG_RUNTIME_DIR` is unset, `/tmp/vault-<uid>` (0700, ownership checked) is used.
* `vault stop` only signals the PID if `/proc/PID/status` says it is a `vaultd` owned by you, which protects against PID reuse.

## File format (`~/.vault`, 0600, written atomically)

```
"VAUT" | version 1 | uint16 BE header length | header JSON | "\n" | nonce(12) ‖ AES-256-GCM ciphertext
```

The full prefix (magic … newline) is GCM *additional authenticated data*, so
the header (salt, iterations, keys) cannot be tampered with.

Header fields: `keytype` (`password` | `ssh-rsa` | `ssh-ed25519` | `ssh-ecdsa-p256`),
`salt` + `pbkdf2_iterations` (password), `public_key`, `wrapped_key` (RSA-OAEP-SHA256),
`ecdh_ephemeral_pub` (Ed25519→X25519 / P-256; AES key = SHA256(shared ‖ "vault-ed25519" | "vault-ecdsa-p256")),
`created_at`.
Payload: `{"credentials": {"key": "value", ...}}`.

## Build & test

```sh
make build      # ./vault ./vaultd for the host
make release    # dist/linux-{amd64,arm64}/{vault,vaultd}
make test       # go vet + end-to-end security suite (tests/)
```

`vault` looks for `vaultd` next to itself first, then in `PATH`, so keep both binaries together.
Requires Go ≥ 1.26 (because of golang.org/x/crypto). Linux only (prctl, SO_PEERCRED).

The tests drive the real binaries through a pseudo-terminal, so passwords are
typed exactly like a human would type them. Each test uses a temporary `HOME` and `XDG_RUNTIME_DIR`.
The test for a second user (SO_PEERCRED) only runs with passwordless `sudo`.
Without it, the rejection is still proven at kernel level with a daemon configured for a foreign UID.

## Limits

* Credentials are decrypted per request. Go strings cannot be reliably wiped, so values can linger in vaultd's heap until GC.
  The key itself is mlocked (best effort) and zeroed on shutdown.
* Root can always read process memory.
* PBKDF2 uses 100k iterations (as specified). The count is stored in the header, so it can be raised later.
