// Package server is the request handler of vaultd. It holds the vault AES
// key in memory; the key is never sent over the socket. The vault file is
// decrypted per request and re-encrypted on every change.
package server

import (
	"encoding/json"
	"errors"
	"io"
	"net"
	"os"
	"sort"
	"sync"
	"time"
	"unicode/utf8"

	vcrypto "vault-system/pkg/crypto"
	"vault-system/pkg/ipc"
	"vault-system/pkg/vaultfile"
)

const (
	MaxKeyLen   = 256
	MaxValueLen = 512 * 1024
)

// ErrPermission is sent to peers whose UID differs from AllowedUID.
var ErrPermission = errors.New("permission denied")

type Server struct {
	key       []byte
	vaultPath string
	KeyType   string
	Started   time.Time
	// AllowedUID is the only UID accepted on the socket (default: our own).
	AllowedUID int

	mu sync.Mutex // serializes read-modify-write of the vault file
}

func New(key []byte, vaultPath string) *Server {
	return &Server{key: key, vaultPath: vaultPath, Started: time.Now(), AllowedUID: os.Getuid()}
}

// Verify checks that the key decrypts the vault file and records its keytype.
func (s *Server) Verify() error {
	f, err := vaultfile.Load(s.vaultPath)
	if err != nil {
		return err
	}
	if _, err := f.Open(s.key); err != nil {
		return err
	}
	s.KeyType = f.Header.KeyType
	return nil
}

// Wipe zeroes the in-memory key.
func (s *Server) Wipe() {
	s.mu.Lock()
	vcrypto.Zero(s.key)
	s.mu.Unlock()
}

// Serve accepts connections until l is closed.
func (s *Server) Serve(l *net.UnixListener) error {
	for {
		c, err := l.AcceptUnix()
		if err != nil {
			if errors.Is(err, net.ErrClosed) {
				return nil
			}
			var ne net.Error
			if errors.As(err, &ne) && ne.Timeout() {
				continue
			}
			time.Sleep(50 * time.Millisecond)
			continue
		}
		go s.HandleConn(c)
	}
}

// CheckPeer enforces that the connecting process runs as uid (SO_PEERCRED).
func CheckPeer(c *net.UnixConn, uid int) error {
	cred, err := ipc.PeerCred(c)
	if err != nil || int(cred.Uid) != uid {
		return ErrPermission
	}
	return nil
}

// HandleConn serves exactly one request on c and closes it.
func (s *Server) HandleConn(c *net.UnixConn) {
	defer c.Close()
	c.SetDeadline(time.Now().Add(30 * time.Second))
	enc := json.NewEncoder(c)

	if err := CheckPeer(c, s.AllowedUID); err != nil {
		enc.Encode(ipc.Response{OK: false, Error: err.Error()})
		return
	}

	var req ipc.Request
	dec := json.NewDecoder(io.LimitReader(c, ipc.MaxMessage))
	if err := dec.Decode(&req); err != nil {
		enc.Encode(ipc.Response{Error: "bad request"})
		return
	}
	enc.Encode(s.handle(&req))
}

func (s *Server) handle(req *ipc.Request) ipc.Response {
	fail := func(msg string) ipc.Response { return ipc.Response{Error: msg} }

	switch req.Op {
	case "ping":
		return ipc.Response{OK: true, PID: os.Getpid(), StartedAt: s.Started.Unix(), KeyType: s.KeyType}

	case "get":
		if err := checkKey(req.Key); err != nil {
			return fail(err.Error())
		}
		p, _, err := s.load()
		if err != nil {
			return fail(err.Error())
		}
		v, ok := p.Credentials[req.Key]
		if !ok {
			return fail("not found: " + req.Key)
		}
		return ipc.Response{OK: true, Value: v}

	case "list":
		p, _, err := s.load()
		if err != nil {
			return fail(err.Error())
		}
		keys := make([]string, 0, len(p.Credentials))
		for k := range p.Credentials {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		return ipc.Response{OK: true, Keys: keys}

	case "add", "delete":
		if err := checkKey(req.Key); err != nil {
			return fail(err.Error())
		}
		if req.Op == "add" {
			if len(req.Value) > MaxValueLen {
				return fail("value too large")
			}
			if !utf8.ValidString(req.Value) {
				return fail("value must be valid UTF-8")
			}
		}
		s.mu.Lock()
		defer s.mu.Unlock()
		p, f, err := s.loadLocked()
		if err != nil {
			return fail(err.Error())
		}
		if req.Op == "add" {
			p.Credentials[req.Key] = req.Value
		} else {
			if _, ok := p.Credentials[req.Key]; !ok {
				return fail("not found: " + req.Key)
			}
			delete(p.Credentials, req.Key)
		}
		data, err := f.Reseal(s.key, p)
		if err != nil {
			return fail("encrypting vault: " + err.Error())
		}
		if err := vaultfile.WriteAtomic(s.vaultPath, data); err != nil {
			return fail("writing vault: " + err.Error())
		}
		return ipc.Response{OK: true}
	}
	return fail("unknown op")
}

func (s *Server) load() (*vaultfile.Payload, *vaultfile.File, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.loadLocked()
}

func (s *Server) loadLocked() (*vaultfile.Payload, *vaultfile.File, error) {
	f, err := vaultfile.Load(s.vaultPath)
	if err != nil {
		return nil, nil, err
	}
	p, err := f.Open(s.key)
	if err != nil {
		return nil, nil, err
	}
	return p, f, nil
}

func checkKey(k string) error {
	if k == "" {
		return errors.New("empty key")
	}
	if len(k) > MaxKeyLen || !utf8.ValidString(k) {
		return errors.New("invalid key")
	}
	return nil
}
