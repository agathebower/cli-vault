// Package vaultfile implements the on-disk vault format:
//
//	[Magic "VAUT" (4)] [Version 1 (1)] [Header length uint16 BE (2)]
//	[Header JSON] ["\n"] [AES-256-GCM ciphertext, nonce prepended]
//
// Everything before the ciphertext (the "prefix") is passed to GCM as
// additional authenticated data, so the header cannot be modified without
// the payload failing to decrypt.
package vaultfile

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"time"

	"vault-system/pkg/crypto"
)

const (
	Magic   = "VAUT"
	Version = 1

	KeyTypePassword = "password"
	KeyTypeRSA      = "ssh-rsa"
	KeyTypeEd25519  = "ssh-ed25519"
	KeyTypeECDSA    = "ssh-ecdsa-p256"

	// DefaultPBKDF2Iterations is used for new password vaults.
	DefaultPBKDF2Iterations = 100000
	// minPBKDF2Iterations guards against nonsensical headers.
	minPBKDF2Iterations = 10000

	fixedLen = len(Magic) + 1 + 2
)

// ErrDecrypt means the vault could not be decrypted with the given key.
var ErrDecrypt = errors.New("failed to decrypt vault (wrong password or key)")

// Header is the plaintext (but authenticated) vault header.
type Header struct {
	KeyType          string `json:"keytype"`
	Salt             string `json:"salt,omitempty"`
	PBKDF2Iterations int    `json:"pbkdf2_iterations,omitempty"`
	PublicKey        string `json:"public_key,omitempty"`
	WrappedKey       string `json:"wrapped_key,omitempty"`
	ECDHEphemeralPub string `json:"ecdh_ephemeral_pub,omitempty"`
	CreatedAt        int64  `json:"created_at"`
}

// Payload is the encrypted part of the vault.
type Payload struct {
	Credentials map[string]string `json:"credentials"`
}

// File is a parsed (still encrypted) vault file.
type File struct {
	Header     Header
	Prefix     []byte // magic..newline, used as AAD
	Ciphertext []byte
}

// DefaultPath returns ~/.vault.
func DefaultPath() (string, error) {
	home, err := os.UserHomeDir()
	if err != nil {
		return "", fmt.Errorf("cannot determine home directory: %w", err)
	}
	return filepath.Join(home, ".vault"), nil
}

// Validate checks that the header is complete for its key type.
func (h *Header) Validate() error {
	switch h.KeyType {
	case KeyTypePassword:
		if h.Salt == "" || h.PBKDF2Iterations < minPBKDF2Iterations {
			return errors.New("invalid vault header: password vault needs salt and pbkdf2_iterations")
		}
	case KeyTypeRSA:
		if h.PublicKey == "" || h.WrappedKey == "" {
			return errors.New("invalid vault header: ssh-rsa vault needs public_key and wrapped_key")
		}
	case KeyTypeEd25519, KeyTypeECDSA:
		if h.PublicKey == "" || h.ECDHEphemeralPub == "" {
			return fmt.Errorf("invalid vault header: %s vault needs public_key and ecdh_ephemeral_pub", h.KeyType)
		}
	default:
		return fmt.Errorf("invalid vault header: unknown keytype %q", h.KeyType)
	}
	return nil
}

func encodePrefix(h *Header) ([]byte, error) {
	if err := h.Validate(); err != nil {
		return nil, err
	}
	hj, err := json.Marshal(h)
	if err != nil {
		return nil, err
	}
	if len(hj) > 0xFFFF {
		return nil, errors.New("vault header too large")
	}
	var b bytes.Buffer
	b.WriteString(Magic)
	b.WriteByte(Version)
	var l [2]byte
	binary.BigEndian.PutUint16(l[:], uint16(len(hj)))
	b.Write(l[:])
	b.Write(hj)
	b.WriteByte('\n')
	return b.Bytes(), nil
}

// Create builds a complete new vault file with the given header and payload.
func Create(h *Header, key []byte, p *Payload) ([]byte, error) {
	prefix, err := encodePrefix(h)
	if err != nil {
		return nil, err
	}
	return seal(prefix, key, p)
}

func seal(prefix, key []byte, p *Payload) ([]byte, error) {
	if p.Credentials == nil {
		p.Credentials = map[string]string{}
	}
	pt, err := json.Marshal(p)
	if err != nil {
		return nil, err
	}
	defer crypto.Zero(pt)
	ct, err := crypto.Encrypt(key, pt, prefix)
	if err != nil {
		return nil, err
	}
	out := make([]byte, 0, len(prefix)+len(ct))
	out = append(out, prefix...)
	return append(out, ct...), nil
}

// Parse splits raw file bytes into header, prefix and ciphertext.
func Parse(data []byte) (*File, error) {
	if len(data) < fixedLen || string(data[:4]) != Magic {
		return nil, errors.New("not a vault file (bad magic)")
	}
	if data[4] != Version {
		return nil, fmt.Errorf("unsupported vault version %d", data[4])
	}
	hl := int(binary.BigEndian.Uint16(data[5:7]))
	end := fixedLen + hl
	if len(data) < end+1 || data[end] != '\n' {
		return nil, errors.New("corrupt vault file (truncated header)")
	}
	f := &File{Prefix: data[:end+1], Ciphertext: data[end+1:]}
	dec := json.NewDecoder(bytes.NewReader(data[fixedLen:end]))
	dec.DisallowUnknownFields()
	if err := dec.Decode(&f.Header); err != nil {
		return nil, fmt.Errorf("corrupt vault header: %w", err)
	}
	if err := f.Header.Validate(); err != nil {
		return nil, err
	}
	return f, nil
}

// Open decrypts the payload.
func (f *File) Open(key []byte) (*Payload, error) {
	pt, err := crypto.Decrypt(key, f.Ciphertext, f.Prefix)
	if err != nil {
		return nil, ErrDecrypt
	}
	defer crypto.Zero(pt)
	var p Payload
	if err := json.Unmarshal(pt, &p); err != nil {
		return nil, fmt.Errorf("corrupt vault payload: %w", err)
	}
	if p.Credentials == nil {
		p.Credentials = map[string]string{}
	}
	return &p, nil
}

// Reseal encrypts a new payload while keeping the header bytes unchanged.
func (f *File) Reseal(key []byte, p *Payload) ([]byte, error) {
	return seal(f.Prefix, key, p)
}

// Load reads and parses the vault file at path.
func Load(path string) (*File, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return nil, fmt.Errorf("no vault found at %s (run 'vault init')", path)
		}
		return nil, err
	}
	return Parse(data)
}

// WriteAtomic writes data to path with mode 0600 via temp file + rename,
// so a crash never leaves a half-written vault behind.
func WriteAtomic(path string, data []byte) error {
	dir := filepath.Dir(path)
	tmp, err := os.CreateTemp(dir, ".vault.tmp-*")
	if err != nil {
		return err
	}
	tmpName := tmp.Name()
	defer os.Remove(tmpName) // no-op after successful rename
	if err := tmp.Chmod(0o600); err != nil {
		tmp.Close()
		return err
	}
	if _, err := tmp.Write(data); err != nil {
		tmp.Close()
		return err
	}
	if err := tmp.Sync(); err != nil {
		tmp.Close()
		return err
	}
	if err := tmp.Close(); err != nil {
		return err
	}
	if err := os.Rename(tmpName, path); err != nil {
		return err
	}
	if d, err := os.Open(dir); err == nil {
		d.Sync()
		d.Close()
	}
	return nil
}

// Backup renames an existing vault to <path>.bak.<epoch> and returns the new name.
func Backup(path string) (string, error) {
	bak := path + ".bak." + strconv.FormatInt(time.Now().Unix(), 10)
	if err := os.Rename(path, bak); err != nil {
		return "", err
	}
	return bak, nil
}
